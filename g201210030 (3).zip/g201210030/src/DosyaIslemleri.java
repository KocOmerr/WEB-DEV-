
/**
*
* @author Ömer Koç - G201210030
* @since 03.04.2024
* <p>
* LOC, Fonksiyon sayısı, yorum satır sayısı vb. gibi değerlerin hesaplandığı dosyadır.
* </p>
*/

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;

public class DosyaIslemleri {

	private static final String JAVA_UZANTISI = ".java";

	public File geciciKlasorOlustur() throws IOException {
		Path tempKlasor = Files.createTempDirectory("kod-analizi");
		return tempKlasor.toFile();
	}

	public File depoKlonla(String url, File geciciKlasor) throws GitAPIException {
		try {
			Git git = Git.cloneRepository().setURI(url).setDirectory(geciciKlasor).call();
			System.out.println("Depo başarıyla klonlandı: " + geciciKlasor.getAbsolutePath());
			return geciciKlasor;
		} catch (GitAPIException e) {
			System.err.println("Hata: Depo klonlama sırasında bir sorun oluştu: " + e.getMessage());
			throw e;
		}
	}

	public void javaDosyalariAnalizEt(File klasor) {
		List<File> javaDosyalari = javaDosyalariGetir(klasor);
		if (javaDosyalari != null && !javaDosyalari.isEmpty()) {
			for (File javaDosyasi : javaDosyalari) {
				javaDosyaAnalizEt(javaDosyasi);
			}
		} else {
			System.out.println("Hata: Klasör içinde *.java uzantılı dosya bulunamadı.");
		}
	}

	private List<File> javaDosyalariGetir(File klasor) {
		List<File> javaDosyalari = new ArrayList<>();
		File[] dosyalar = klasor.listFiles();
		if (dosyalar != null) {
			for (File dosya : dosyalar) {
				if (dosya.isDirectory()) {
					javaDosyalari.addAll(javaDosyalariGetir(dosya));
				} else if (dosya.getName().endsWith(JAVA_UZANTISI) && sinifDosyasiMi(dosya)) {
					javaDosyalari.add(dosya);
				}
			}
		}
		return javaDosyalari;
	}

	private boolean sinifDosyasiMi(File dosya) {
		try (BufferedReader okuyucu = new BufferedReader(new FileReader(dosya))) {
			String satir;
			while ((satir = okuyucu.readLine()) != null) {
				if (satir.contains(" class ") && !satir.contains("//") && !satir.contains("/*")) {
					return true;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	private void javaDosyaAnalizEt(File javaDosyasi) {
		int javadocSatirSayisi = 0;
		int yorumSatirSayisi = 0;
		int kodSatirSayisi = 0;
		int loc = 0;
		int fonksiyonSayisi = 0;

		try (BufferedReader okuyucu = new BufferedReader(new FileReader(javaDosyasi))) {
			String satir;
			boolean yorumIcerisindeMi = false;
			boolean javadocIcerisindeMi = false;

			Pattern fonksiyonPattern = Pattern
					.compile("^\\s*(public|private|protected)?\\s*\\w+\\s+\\w+\\s*\\(.*\\)\\s*\\{?\\s*$");
			Pattern starPattern = Pattern.compile("\\*");

			while ((satir = okuyucu.readLine()) != null) {
				// LoC (Line of Code)
				loc++;

				satir = satir.trim();

				Matcher fonksiyonMatcher = fonksiyonPattern.matcher(satir);
				Matcher startMatcher = starPattern.matcher(satir);

				// Javadoc Satır sayısı
				if (satir.startsWith("/**")) {
					javadocIcerisindeMi = true;
					continue;
				}

				if (javadocIcerisindeMi && !yorumIcerisindeMi) {
					if (satir.contains("*/")) {
						javadocIcerisindeMi = false;
						continue;
					}

					Pattern pattern = Pattern.compile("\\*+\\s?([^*/]*)");
					Matcher matcher = pattern.matcher(satir);

					while (matcher.find()) {
						javadocSatirSayisi++;
					}
				}

				// Yorum Satır Sayısı
				if (satir.contains("//")) {
					yorumSatirSayisi++;
				}
				if (satir.startsWith("/*")) {
					yorumIcerisindeMi = true;
				}
				if (satir.endsWith("*/")) {
					yorumIcerisindeMi = false;
				}
				if (yorumIcerisindeMi && !satir.startsWith("/*") && !satir.endsWith("*/")) {
					yorumSatirSayisi++;
				}

				if (fonksiyonMatcher.matches()) {
					fonksiyonSayisi++;
				}

				// Kod Satır Sayısı
				if (!satir.isEmpty() && !javadocIcerisindeMi && !yorumIcerisindeMi && !satir.startsWith("//")
						&& !satir.startsWith("/*") && !satir.endsWith("*/")) {
					kodSatirSayisi++;
				}

			}

		} catch (

		IOException e) {
			System.err.println("Hata: Dosya okumada bir hata oluştu.. " + e.getMessage());
			return;
		}

		double yg = ((javadocSatirSayisi + yorumSatirSayisi) * 0.8) / (fonksiyonSayisi == 0 ? 1 : fonksiyonSayisi);
		double yh = ((double) kodSatirSayisi / (fonksiyonSayisi == 0 ? 1 : fonksiyonSayisi)) * 0.3;
		double yorumSapmaYuzdesi = ((100 * yg) / yh) - 100;

		System.out.println("Sınıf: " + javaDosyasi.getName());
		System.out.println("Javadoc Satır Sayısı: " + javadocSatirSayisi);
		System.out.println("Yorum Satırı Sayısı: " + yorumSatirSayisi);
		System.out.println("Kod Satır Sayısı: " + kodSatirSayisi);
		System.out.println("LOC: " + loc);
		System.out.println("Fonksiyon Sayısı: " + fonksiyonSayisi);
		System.out.println("Yorum Sapma Yüzdesi: %" + String.format("%.2f", yorumSapmaYuzdesi));
		System.out.println("-----------------------------------------");
	}

	public void geciciKlasorSil(File folder) {
		if (folder.isDirectory()) {
			File[] files = folder.listFiles();
			if (files != null) {
				for (File file : files) {
					geciciKlasorSil(file);
				}
			}
		}
		folder.delete();
	}
}
