
/**
*
* @author Ömer Koç - G201210030
* @since 03.04.2024
* <p>
* Kullanıcıdan Github Repository Url'inin istendiği ve kullanıcı girişinin yapıldığı, aynı zamanda diğer fonksiyonların çağrıldığı dosyadır.
* </p>
*/

import java.io.IOException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException {
		Scanner tarayici = new Scanner(System.in);

		System.out.println("GitHub Repository URL'sini giriniz: ");
		String depoURL = tarayici.nextLine();

		RepoIslemleri analizci = new RepoIslemleri();
		analizci.depoKlonlaVeAnalizEt(depoURL);

		tarayici.close();
	}
}
