
/**
*
* @author Ömer Koç - G201210030
* @since 03.04.2024
* <p>
* Repository klonlanma işlemlerinin yapıldığı dosyadır.
* </p>
*/

import java.io.File;
import java.io.IOException;

import org.eclipse.jgit.api.errors.GitAPIException;

public class RepoIslemleri {

	public void depoKlonlaVeAnalizEt(String url) throws IOException {
		DosyaIslemleri dosyaIslemleri = new DosyaIslemleri();
		File tempKlasor = dosyaIslemleri.geciciKlasorOlustur();

		try {
			File depoKlasoru = dosyaIslemleri.depoKlonla(url, tempKlasor);
			dosyaIslemleri.javaDosyalariAnalizEt(depoKlasoru);
		} catch (GitAPIException e) {
			System.err.println("Hata: Depo klonlamada hata oluştu.. " + e.getMessage());
		} finally {
			dosyaIslemleri.geciciKlasorSil(tempKlasor);
		}
	}
}
